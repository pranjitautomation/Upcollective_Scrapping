# Template: Basic Python only robot

Get started with just Python.

This template robot:

- Uses only Python.
- Provides a simple template to start from (`task.py`).

## Learning materials

- [Python basics](https://robocorp.com/docs/languages-and-frameworks/python)
- [Best practices in creating Python robots](https://robocorp.com/docs/development-guide/qa-and-best-practices/python-robots)
