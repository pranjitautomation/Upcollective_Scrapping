from process import Process


def minimal_task():
    obj = Process()
    obj.all_steps()
    print("Done.")


if __name__ == "__main__":
    minimal_task()
